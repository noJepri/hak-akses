luwih enak kentang
