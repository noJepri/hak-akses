<?php $__env->startSection('content'); ?>
<section class="main-section">
        <div class="content">
            <h1>Ubah Barang</h1>
            <hr>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('barang.update', $datas->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
                <label for="kd_barang">kd_barang:</label>
                <input type="text" class="form-control" id="brng" name="kd_barang" value="<?php echo e($datas->kd_barang); ?>">
            </div>
            </div>
            <div class="form-group">
                <label for="nama_barang">nama_barang:</label>
                <input type="text" class="form-control" id="nama" name="nama_barang" value="<?php echo e($datas->nama_barang); ?>">
            </div>
            <div class="form-group">
                <label for="stok">stok:</label>
                <input type="text" class="form-control" id="stok" name="stok" value="<?php echo e($datas->stok); ?>">
            </div>
            <div class="form-group">
                <label for="harga">harga:</label>
                <input type="text" class="form-control" id="harga" name="harga" value="<?php echo e($datas->harga); ?>">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Submit</button>
                <button type="reset" class="btn btn-md btn-danger">Cancel</button>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\uwu\resources\views/barang_edit.blade.php ENDPATH**/ ?>