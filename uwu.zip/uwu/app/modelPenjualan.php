<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modelPenjualan extends Model
{
    protected $table ="model_penjualans";
}
